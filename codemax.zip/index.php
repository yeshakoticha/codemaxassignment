<?php 

require_once 'bootstrap/App.php';
require_once 'controllers/Controller.php';
require_once 'bootstrap/View.php';
require_once 'database/Connection.php';
require_once 'models/Model.php';
require_once 'config/params.php';
// $conn = new Connection();

$app = new App();


?>