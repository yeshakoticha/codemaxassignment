<?php 

define('URL','http://thestockderby.com/inventory/');

?>